from fbrute import main

main()